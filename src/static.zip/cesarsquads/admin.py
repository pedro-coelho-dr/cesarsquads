from django.contrib import admin
from .models import Profile, Tribe, Squad

# Register your models here.

admin.site.register(Profile)
admin.site.register(Tribe)
admin.site.register(Squad)
