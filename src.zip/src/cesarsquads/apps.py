from django.apps import AppConfig


class CesarsquadsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'cesarsquads'
